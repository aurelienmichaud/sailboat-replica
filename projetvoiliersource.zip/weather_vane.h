#ifndef _WEATHER_VANE_H
#define _WEATHER_VANE_H

void weather_vane_init(void);
int weather_vane_get_position(void);
void weather_vane_start_counting(void);

#endif // _WEATHER_VANE_H
