#ifndef _MAIN_CONTROLLER_H_
#define _MAIN_CONTROLLER_H_

void main_controller_start(void);

#endif //_MAIN_CONTROLLER_H_
